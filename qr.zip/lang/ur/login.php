<?php
return [
    'welcome' => "آپ کے ڈیش بورڈ میں خوش آمدید",
];